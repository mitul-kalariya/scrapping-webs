from crwtimesnownews.main import Crawler
