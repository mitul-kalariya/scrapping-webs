from crwctvnews.main import Crawler
