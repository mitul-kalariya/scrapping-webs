BASE_URL = "http://www.sueddeutsche.de/"
SITEMAP_URL = "https://www.sueddeutsche.de/archiv"
