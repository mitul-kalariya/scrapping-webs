from crweconomist.main import Crawler
