from datetime import datetime
import logging

TODAYS_DATE = datetime.today().date()
BASE_URL = "https://www.zdf.de/"
SITEMAP_URL = "https://www.zdf.de/sitemap.xml"

LOGGER = logging.getLogger()
