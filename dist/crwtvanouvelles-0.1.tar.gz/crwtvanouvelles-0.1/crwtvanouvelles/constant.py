"""constants"""

SITEMAP_URL = "https://www.tvanouvelles.ca/news.xml"
# In case when sitemap, RSS feed or archive is not available.
BASE_URL = "http://www.tvanouvelles.ca/"
