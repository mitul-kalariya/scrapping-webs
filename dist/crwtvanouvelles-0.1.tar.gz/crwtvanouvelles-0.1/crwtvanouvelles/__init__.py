from crwtvanouvelles.main import Crawler
