from crwfrancetv.main import Crawler
