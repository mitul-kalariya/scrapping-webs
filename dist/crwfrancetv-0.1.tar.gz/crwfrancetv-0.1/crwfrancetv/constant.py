"""constants"""

SITEMAP_URL = "https://www.francetvinfo.fr/sitemap_news.xml"

