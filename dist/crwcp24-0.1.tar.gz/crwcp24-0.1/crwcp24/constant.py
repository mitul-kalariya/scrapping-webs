"""constants"""

SITEMAP_URL = "https://www.cp24.com/sitemap.xml"
