from datetime import datetime
import logging

TODAYS_DATE = datetime.today().date()
BASE_URL = "https://www.mediapart.fr"
SITEMAP_URL = "https://www.mediapart.fr/sitemap_index.xml"
LOGGER = logging.getLogger()
