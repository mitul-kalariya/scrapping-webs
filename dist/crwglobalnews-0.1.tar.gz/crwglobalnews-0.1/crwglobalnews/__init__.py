from crwglobalnews.main import Crawler
