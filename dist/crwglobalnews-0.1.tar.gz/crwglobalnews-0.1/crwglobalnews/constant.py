from datetime import datetime
import logging

TODAYS_DATE = datetime.today().date()
LOGGER = logging.getLogger()
BASE_URL = "https://globalnews.ca/"
SITEMAP_URL = "http://globalnews.ca/news-sitemap.xml"
