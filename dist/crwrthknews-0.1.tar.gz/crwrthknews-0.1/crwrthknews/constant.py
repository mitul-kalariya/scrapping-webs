"""constants"""

SITEMAP_URL = "https://news.rthk.hk/rthk/en/news-archive.htm"
# In case when sitemap, RSS feed or archive is not available.
BASE_URL = "https://news.rthk.hk/rthk/en/"
