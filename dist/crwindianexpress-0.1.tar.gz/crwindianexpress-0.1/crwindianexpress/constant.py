"""constants"""

SITEMAP_URL = ""
# In case when sitemap, RSS feed or archive is not available.
BASE_URL = ""
